package pl.akmf.ksef.sdk.client.model.permission.search;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public class EntityAuthorizationsAuthorIdentifier {
    private String value;
    private IdentifierType type;

    public EntityAuthorizationsAuthorIdentifier() {

    }

    public EntityAuthorizationsAuthorIdentifier(final String value, final IdentifierType type) {
        this.value = value;
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(final String value) {
        this.value = value;
    }

    public IdentifierType getType() {
        return type;
    }

    public void setType(final IdentifierType type) {
        this.type = type;
    }

    public enum IdentifierType {

        NIP("Nip"),

        PESEL("Pesel"),

        FINGERPRINT("Fingerprint");

        private final String value;

        IdentifierType(String value) {
            this.value = value;
        }

        @JsonValue
        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        @JsonCreator
        public static IdentifierType fromValue(String value) {
            for (IdentifierType b : IdentifierType.values()) {
                if (b.value.equalsIgnoreCase(value)) {
                    return b;
                }
            }
            throw new IllegalArgumentException("Unexpected value '" + value + "'");
        }
    }
}